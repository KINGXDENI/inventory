<footer class="footer fixed-bottom bg-white">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12 text-center">
                <p>&copy; <?= date('Y') ?> Sistem Inventory Barang</p>
            </div>
        </div>
    </div>
</footer>